$("input[value='Post without Preview']").attr("accesskey", "z");
$("input[value='Preview Message']").attr("accesskey", "x");
