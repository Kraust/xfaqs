xFAQs for Chrome.

This may not be the up to date version of the Extension.