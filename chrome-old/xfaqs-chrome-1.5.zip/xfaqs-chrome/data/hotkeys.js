$("input[value='Post Message']").attr("accesskey", "z");
$("input[value='Preview Message']").attr("accesskey", "x");
